package castingTest;

public class CastingTest02 {
	public static void main(String[] args) {
		char data = 48;
		
		// 자동 형변환
		System.out.println(data);
		System.out.println('A' + 20);
		
		// 강제 형변환
		System.out.println((char)50);
	}
}
