package castingTest;

public class CastingTest04 {
	public static void main(String[] args) {
		System.out.println(Integer.parseInt("10") + 4);
		
//		결과가 6.0이 나오도록 형변환한다.
		System.out.println(Double.parseDouble("3.5") + 2.5);
	}
}
