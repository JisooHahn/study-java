package controlStatementTest;

public class ForTask {
	public static void main(String[] args) {
//		브론즈
//		1 ~ 100까지 출력
		
//		100 ~ 1까지 출력
		
//		1 ~ 100까지 중 짝수만 출력
		
//		실버
//		1 ~ 10까지 합 출력
		
//		1 ~ n까지 합 출력(n은 입력받기)
		
//		골드
//		A ~ F까지 출력
		
//		A ~ F까지 중 C 제외하고 출력(continue 사용하지 않기)
		
//		다이아
		
//		0 1 2 0 1 2 0 1 2 0 1 2 출력
		
//		aBcDeF...Z 출력
	}
}











