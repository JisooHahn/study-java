package variableTest;

public class ConstantTest {
	public static void main(String[] args) {
		final int LOGIN_SUCCESS_STATUS = 0;
		final int LOGIN_FAIL_STATUS = 1;
		final int LOGIN_ADMIN_STATUS = 2;
	}
}
